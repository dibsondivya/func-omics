Functional omics project using publicly available Alzheimer's dataset from BioStudies, as part of Statistics in Bioinformatics course 2024. 

GSE53697: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE53697 

Regulatory consequences of neuronal ELAV-like protein binding to coding and non-coding RNAs in human brain: https://elifesciences.org/articles/10421
